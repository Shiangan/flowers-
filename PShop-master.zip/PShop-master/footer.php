</div><!--#wrap-->
<footer id="footer">
	<div class="container"><?=$option->sitename?><br/>Powered by PShop購物車</div>
</footer>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
</body>
</html>